#pragma once


// Functions
void scan_restart(void *arg);