#pragma once


/* PROTOTYPES */
/**
 * @brief Trim the trailing whitespaces of a given string.
 *
 * @param inp The string we want to modify.
 */
void trim(char *inp);